# ====================================================================================
#  DragonRuby's Primer for the Ruby Programming Language
# ====================================================================================
#
# Welcome you awesome person you. Look at the txt files. Copy what's in there
# and paste it here. Save this file. The code will automatically execute
# and you'll see the output in the console window.
